Hi {{$name}},
<br/>

<p>You have been succeefully registered on the Open Treasury Platform</p>

<p>Your password is: {{$password}}</p>


<p>Kind regards</p>

