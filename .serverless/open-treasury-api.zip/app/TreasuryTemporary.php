<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TreasuryTemporary extends Model
{
    protected $guarded = ['id'];
}
