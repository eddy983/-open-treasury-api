<?php

namespace App\Http\Controllers;

use App\Treasury;
use Illuminate\Http\Request;

class TreasuryController extends Controller
{
    public function get()
    {
        $treasuries = Treasury::all();

        return response()
                ->json(compact("treasuries"));
    }
}
